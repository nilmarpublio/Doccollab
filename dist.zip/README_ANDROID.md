
# 🚀 Guia de Transferência para o Android Studio

Siga estes passos exatamente na ordem para levar o **Atlas Alert** para o seu celular:

### 1. Preparação (No Terminal/PowerShell)
Abra a pasta `D:\atlasalert` no seu terminal e rode:
```bash
npm install
```
*Isso vai baixar todas as bibliotecas necessárias.*

### 2. Criar o Projeto Android
Rode o comando que cria a "ponte" com o Android Studio:
```bash
npx cap add android
```
*Após isso, uma pasta chamada `android` aparecerá dentro de `D:\atlasalert`.*

### 3. Sincronizar Arquivos
Sempre que você mudar algo no código aqui, rode:
```bash
npx cap sync android
```

### 4. Abrir no Android Studio
Você tem duas opções:
- **Pelo Terminal:** `npx cap open android`
- **Manual:** Abra o Android Studio, vá em **Open** e selecione a pasta `D:\atlasalert\android`.

### 5. Gerar o APK / Rodar
No Android Studio:
1. Espere o "Gradle Sync" terminar (barra de progresso embaixo).
2. Clique no ícone de **Play** (triângulo verde) para rodar no seu celular ou emulador.
3. Para gerar o instalador, vá em: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---
**Dica:** Se o Android Studio reclamar de permissões, o Capacitor já configurou o básico no `AndroidManifest.xml`, mas você pode conferir na pasta `app/src/main`.
