import { GoogleGenAI } from "@google/genai";
import { WeatherData, Language } from "../types";
import { getWeatherDescription } from "../constants";

export const getWeatherInsight = async (weather: WeatherData, lang: Language): Promise<string> => {
  try {
    // ALWAYS initialize the client inside the function to ensure current API key is used
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const langNames = { pt: 'Português', en: 'English', es: 'Español' };
    const prompt = `
      Act as a friendly meteorologist. Provide a brief summary (max 3 sentences) about the current weather in ${weather.location.name}.
      Data: 
      - Temperature: ${weather.current.temp}°C
      - Condition: ${getWeatherDescription(weather.current.description, lang)}
      - Humidity: ${weather.current.humidity}%
      - Wind: ${weather.current.windSpeed} km/h
      Give one practical tip (e.g. carry an umbrella, use sunscreen, dress warm). 
      IMPORTANT: Respond ONLY in ${langNames[lang]}.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "No insights available.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not generate AI insight.";
  }
};

export const getWeatherNews = async (location: string, lang: Language) => {
  try {
    // ALWAYS initialize the client inside the function
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Find 2 recent news or alerts regarding weather or climate in ${location}. Provide a summarized report.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    /**
     * GUIDELINE FOLLOWED:
     * 1. Extract URLs from groundingChunks and list them on the web app.
     * 2. The output response.text may not be in JSON format when using googleSearch; do not attempt to parse it as JSON.
     */
    const text = response.text || "";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = groundingChunks
      .filter((chunk: any) => chunk.web)
      .map((chunk: any) => chunk.web) || [];
    
    // Construct a safe data structure for the UI since direct JSON parsing is discouraged for search grounding
    const news = [{
      title: lang === 'pt' ? "Notícias em Destaque" : lang === 'es' ? "Noticias Destacadas" : "Featured News",
      summary: text,
      url: sources[0]?.uri || ""
    }];
    
    return { news, sources };
  } catch (error) {
    console.error("News Error:", error);
    return { news: [], sources: [] };
  }
};