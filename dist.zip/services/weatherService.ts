
import { WeatherData, GeocodingResult, WeatherAlert, Language } from '../types';

export const fetchWeather = async (lat: number, lon: number, name: string, lang: Language): Promise<WeatherData> => {
  // 1. Fetch Forecast
  const forecastUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,surface_pressure,wind_speed_10m,wind_direction_10m,visibility&hourly=temperature_2m,weather_code,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max&timezone=auto`;
  
  // 2. Fetch Air Quality (Pollen)
  const airQualityUrl = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=alder_pollen,birch_pollen,grass_pollen,mugwort_pollen,olive_pollen,ragweed_pollen&timezone=auto`;

  const [forecastRes, airQualityRes] = await Promise.all([
    fetch(forecastUrl),
    fetch(airQualityUrl)
  ]);

  if (!forecastRes.ok) throw new Error('Erro ao buscar dados meteorológicos');
  
  const data = await forecastRes.json();
  const airData = await airQualityRes.json();

  const currentPollen = airData.current || {};
  
  // 3. Process Alerts with Translations
  const alerts: WeatherAlert[] = [];
  // Fix: Renamed 'desc' to 'description' to match WeatherAlert interface and fixed Spanish typo
  const alertTexts: Record<string, Record<Language, { title: string, description: string }>> = {
    storm: {
      pt: { title: 'Alerta de Tempestade', description: 'Tempestades elétricas detectadas. Evite áreas abertas.' },
      en: { title: 'Storm Alert', description: 'Thunderstorms detected. Avoid open areas.' },
      es: { title: 'Alerta de Tormenta', description: 'Tormentas eléctricas detectadas. Evite áreas abiertas.' }
    },
    flood: {
      pt: { title: 'Risco de Alagamento', description: 'Chuva torrencial pode causar enchentes rápidas.' },
      en: { title: 'Flood Risk', description: 'Torrential rain may cause flash flooding.' },
      es: { title: 'Riesgo de Inundación', description: 'La lluvia torrencial puede causar inundaciones repentinas.' }
    },
    uv_extreme: {
      pt: { title: 'Radiação UV Extrema', description: 'Evite o sol. Risco de queimaduras em minutos.' },
      en: { title: 'Extreme UV Radiation', description: 'Avoid the sun. Risk of burns in minutes.' },
      es: { title: 'Radiación UV Extrema', description: 'Evite el sol. Riesgo de quemaduras en minutos.' }
    },
    heat: {
      pt: { title: 'Calor Extremo', description: 'Mantenha-se hidratado. Risco de insolação.' },
      en: { title: 'Extreme Heat', description: 'Stay hydrated. Heat stroke risk.' },
      es: { title: 'Calor Extremo', description: 'Manténgase hidratado. Riesgo de insolación.' }
    },
    dry: {
      pt: { title: 'Umidade Crítica', description: 'Ar muito seco. Beba bastante água.' },
      en: { title: 'Critical Humidity', description: 'Very dry air. Drink plenty of water.' },
      es: { title: 'Humedad Crítica', description: 'Aire muy seco. Beba mucha agua.' }
    }
  };

  const code = data.current.weather_code;
  if ([95, 96, 99].includes(code)) {
    alerts.push({ id: 's1', type: 'storm', severity: 'critical', ...alertTexts.storm[lang] });
  } else if ([65, 82].includes(code)) {
    alerts.push({ id: 'f1', type: 'flood', severity: 'warning', ...alertTexts.flood[lang] });
  }

  const uv = data.daily.uv_index_max[0];
  if (uv >= 10) {
    alerts.push({ id: 'u1', type: 'uv', severity: 'critical', ...alertTexts.uv_extreme[lang] });
  }

  const temp = data.current.temperature_2m;
  if (temp >= 38) {
    alerts.push({ id: 'h1', type: 'heat', severity: 'critical', ...alertTexts.heat[lang] });
  }

  const humidity = data.current.relative_humidity_2m;
  if (humidity <= 20) {
    alerts.push({ id: 'hum1', type: 'humidity', severity: 'warning', ...alertTexts.dry[lang] });
  }

  return {
    current: {
      temp: Math.round(data.current.temperature_2m),
      description: data.current.weather_code,
      icon: data.current.weather_code,
      humidity: data.current.relative_humidity_2m,
      windSpeed: data.current.wind_speed_10m,
      windDirection: data.current.wind_direction_10m,
      pressure: data.current.surface_pressure,
      uvIndex: data.daily.uv_index_max[0],
      visibility: data.current.visibility / 1000,
      isDay: data.current.is_day === 1,
    },
    hourly: data.hourly.time.slice(0, 24).map((time: string, i: number) => ({
      time: time,
      temp: Math.round(data.hourly.temperature_2m[i]),
      icon: data.hourly.weather_code[i],
      pop: data.hourly.precipitation_probability[i],
    })),
    daily: data.daily.time.map((date: string, i: number) => ({
      date: date,
      minTemp: Math.round(data.daily.temperature_2m_min[i]),
      maxTemp: Math.round(data.daily.temperature_2m_max[i]),
      icon: data.daily.weather_code[i],
      description: data.daily.weather_code[i],
    })),
    astronomy: {
      sunrise: data.daily.sunrise[0],
      sunset: data.daily.sunset[0],
    },
    location: { name, lat, lon },
    pollen: {
      grass: currentPollen.grass_pollen || 0,
      ragweed: currentPollen.ragweed_pollen || 0,
      birch: currentPollen.birch_pollen || 0,
    },
    alerts,
  };
};

export const searchLocations = async (query: string, lang: Language): Promise<GeocodingResult[]> => {
  if (query.length < 3) return [];
  const apiLang = lang === 'pt' ? 'pt' : lang === 'es' ? 'es' : 'en';
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=5&language=${apiLang}&format=json`;
  const response = await fetch(url);
  const data = await response.json();
  return data.results || [];
};
