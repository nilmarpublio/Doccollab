
import React, { useState, useEffect, useCallback } from 'react';
import { Search, MapPin, Wind, Droplets, Sun, Loader2, Globe, Download, Share2, AlertCircle, WifiOff, Info, MessageSquare, ShieldCheck, FileText, Mail } from 'lucide-react';
import { WeatherData, GeocodingResult, Language } from './types';
import { fetchWeather, searchLocations } from './services/weatherService';
import { getWeatherInsight, getWeatherNews } from './services/geminiService';
import { WEATHER_ICONS, getWeatherDescription } from './constants';
import { translations } from './translations';
import HourlyForecast from './components/HourlyForecast';
import WeeklyForecast from './components/WeeklyForecast';
import SunPath from './components/SunPath';
import WeatherLayersMap from './components/WeatherLayersMap';
import SatelliteMap from './components/SatelliteMap';
import WindMap from './components/WindMap';
import WeatherAlerts from './components/WeatherAlerts';
import AdPlaceholder from './components/AdPlaceholder';
import WeatherNews from './components/WeatherNews';
import LegalModal from './components/LegalModal';

const APP_NAME = "WeatherWise"; 

const App: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GeocodingResult[]>([]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [insight, setInsight] = useState<string>('');
  const [newsData, setNewsData] = useState<{news: any[], sources: any[]}>({news: [], sources: []});
  const [loading, setLoading] = useState(true);
  const [insightLoading, setInsightLoading] = useState(false);
  const [unit, setUnit] = useState<'C' | 'F'>('C');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isNative, setIsNative] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [legalPage, setLegalPage] = useState<'privacy' | 'terms' | 'about' | 'contact' | null>(null);
  
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('app_lang');
    if (saved) return saved as Language;
    const browserLang = navigator.language.split('-')[0];
    return (['pt', 'en', 'es'].includes(browserLang) ? browserLang : 'en') as Language;
  });

  const t = translations[lang];

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    if ((window as any).Capacitor || navigator.userAgent.includes('Android')) {
      setIsNative(true);
    }

    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    }
  };

  const handleShare = async () => {
    if (weather && navigator.share) {
      try {
        await navigator.share({
          title: `${APP_NAME} - ${weather.location.name}`,
          text: `Confira o clima em ${weather.location.name}: ${weather.current.temp}°C e ${getWeatherDescription(weather.current.description, lang)}.`,
          url: window.location.href,
        });
      } catch (err) {
        console.log("Error sharing", err);
      }
    }
  };

  const getDynamicBackground = () => {
    if (!weather) return 'bg-clear-day';
    const code = weather.current.description;
    const isDay = weather.current.isDay;
    if ([95, 96, 99].includes(code)) return 'bg-storm';
    if ([51, 53, 55, 61, 63, 65, 80, 81, 82].includes(code)) return 'bg-rainy';
    if ([3, 45, 48].includes(code)) return 'bg-cloudy';
    return isDay ? 'bg-clear-day' : 'bg-clear-night';
  };

  const loadWeather = useCallback(async (lat: number, lon: number, name: string) => {
    setLoading(true);
    setApiError(false);
    try {
      const data = await fetchWeather(lat, lon, name, lang);
      setWeather(data);
      localStorage.setItem('last_location', JSON.stringify({ lat, lon, name }));
      setInsightLoading(true);
      
      try {
        const [aiSummary, news] = await Promise.all([
          getWeatherInsight(data, lang),
          getWeatherNews(name, lang)
        ]);
        setInsight(aiSummary);
        setNewsData(news);
      } catch (aiErr) {
        setInsight(lang === 'pt' ? "Insights de IA indisponíveis no momento." : "AI Insights currently unavailable.");
      }
      
    } catch (error) {
      setApiError(true);
    } finally {
      setInsightLoading(false);
      setLoading(false);
    }
  }, [lang]);

  useEffect(() => {
    const saved = localStorage.getItem('last_location');
    if (saved) {
      const { lat, lon, name } = JSON.parse(saved);
      loadWeather(lat, lon, name);
    } else if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => loadWeather(pos.coords.latitude, pos.coords.longitude, lang === 'pt' ? "Localização Atual" : lang === 'es' ? "Ubicación Actual" : "Current Location"),
        () => loadWeather(-23.5505, -46.6333, "São Paulo"),
        { timeout: 10000 }
      );
    } else {
      loadWeather(-23.5505, -46.6333, "São Paulo");
    }
  }, [loadWeather, lang]);

  const selectLocation = (loc: GeocodingResult) => {
    loadWeather(loc.latitude, loc.longitude, `${loc.name}, ${loc.country}`);
    setQuery('');
    setResults([]);
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && results.length > 0) {
      selectLocation(results[0]);
    }
  };

  const convertTemp = (temp: number) => unit === 'F' ? Math.round((temp * 9/5) + 32) : temp;

  if (loading && !weather) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center animate-pulse">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-slate-600 font-bold uppercase tracking-widest text-[10px]">{t.syncing}</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-slate-50 text-slate-900 pb-12 transition-colors duration-700 ${isNative ? 'pt-2' : ''}`}>
      {!isOnline && (
        <div className="bg-orange-500 text-white text-[10px] font-black uppercase py-2 px-4 flex items-center justify-center gap-2 sticky top-0 z-[60]">
          <WifiOff size={12} /> {lang === 'pt' ? 'Você está offline • Dados em cache' : 'You are offline • Cached data'}
        </div>
      )}
      
      <header className="bg-white/90 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-xl shadow-lg shadow-blue-200 cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
              <Sun className="text-white w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-xl font-extrabold tracking-tight leading-none">
                {APP_NAME}
              </h1>
              <span className="text-[8px] font-black uppercase tracking-widest text-blue-600">v1.0 Release</span>
            </div>
          </div>
          
          <div className="relative flex-1 max-w-md">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2 bg-slate-100 border-2 border-transparent focus:border-blue-500/20 focus:bg-white rounded-2xl outline-none text-sm transition-all"
                value={query}
                onKeyDown={handleKeyDown}
                onChange={async (e) => {
                  setQuery(e.target.value);
                  if (e.target.value.length >= 3) {
                    const res = await searchLocations(e.target.value, lang);
                    setResults(res);
                  } else {
                    setResults([]);
                  }
                }}
              />
            </div>
            {results.length > 0 && (
              <ul className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-in fade-in zoom-in-95 duration-200">
                {results.map((loc, idx) => (
                  <li key={idx} className="px-4 py-3 hover:bg-blue-50 cursor-pointer flex items-center gap-3 border-b border-slate-50 last:border-none" onClick={() => selectLocation(loc)}>
                    <div className="bg-slate-100 p-2 rounded-lg text-slate-400"><MapPin size={14} /></div>
                    <div>
                      <p className="text-sm font-bold text-slate-700">{loc.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{loc.admin1 ? `${loc.admin1}, ` : ''}{loc.country}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
             <button onClick={handleShare} className="p-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-slate-600 transition-all active:scale-95" title="Compartilhar">
               <Share2 size={18} />
             </button>

             <div className="flex items-center bg-slate-100 rounded-xl px-2 py-1 gap-1">
                <Globe size={14} className="text-slate-400 ml-1" />
                <select 
                  value={lang} 
                  onChange={(e) => setLang(e.target.value as Language)}
                  className="bg-transparent text-[10px] font-black uppercase tracking-widest outline-none cursor-pointer text-slate-600 py-1"
                >
                  <option value="pt">PT</option>
                  <option value="en">EN</option>
                  <option value="es">ES</option>
                </select>
             </div>

             <button 
              onClick={() => setUnit(unit === 'C' ? 'F' : 'C')}
              className="px-3 py-1 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-black text-slate-600 transition-all"
            >
              °{unit}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 mt-6">
        {apiError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-800">
            <AlertCircle size={20} />
            <p className="text-sm font-bold">{lang === 'pt' ? 'Erro de conexão.' : 'Connection error.'}</p>
          </div>
        )}

        <AdPlaceholder type="banner" lang={lang} />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            {weather && <WeatherAlerts alerts={weather.alerts} />}

            <div className={`rounded-[2.5rem] p-8 md:p-12 text-white relative overflow-hidden shadow-2xl transition-all duration-1000 ${getDynamicBackground()}`}>
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-2 bg-white/20 backdrop-blur-md w-fit px-4 py-1.5 rounded-full border border-white/10">
                  <MapPin className="w-3 h-3 text-white" />
                  <span className="text-xs font-bold uppercase tracking-widest">{weather?.location.name}</span>
                </div>
                
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mt-4">
                  <div>
                    <div className="flex items-start">
                       <h2 className="text-9xl font-black tracking-tighter leading-none">{convertTemp(weather?.current.temp || 0)}</h2>
                       <span className="text-4xl font-light mt-4 opacity-50">°</span>
                    </div>
                    <p className="text-2xl font-bold mt-4 tracking-tight">
                      {getWeatherDescription(weather?.current.description || 0, lang)}
                    </p>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="scale-[4] origin-bottom-right mb-4 drop-shadow-2xl">
                      {WEATHER_ICONS[weather?.current.description || 0]}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 pt-8 border-t border-white/10">
                  {[
                    { icon: <Wind size={20} />, label: t.wind, value: `${weather?.current.windSpeed} km/h` },
                    { icon: <Droplets size={20} />, label: t.humidity, value: `${weather?.current.humidity}%` },
                    { icon: <Sun size={20} />, label: t.uvIndex, value: weather?.current.uvIndex },
                    { icon: <Info size={16} />, label: t.visibility, value: `${weather?.current.visibility} km` }
                  ].map((item, i) => (
                    <div key={i} className="bg-white/10 backdrop-blur-md p-4 rounded-3xl border border-white/5 flex flex-col items-center text-center">
                      <div className="opacity-60 mb-2">{item.icon}</div>
                      <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">{item.label}</p>
                      <p className="font-black text-sm">{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-100 p-6 rounded-[2rem] shadow-sm relative overflow-hidden group border-l-4 border-l-blue-600">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-lg">
                  <span className="text-white text-[12px] font-black">AI</span>
                </div>
                <h3 className="font-extrabold text-slate-800 tracking-tight">{t.aiInsightTitle}</h3>
              </div>
              {insightLoading ? (
                <div className="space-y-2 animate-pulse">
                  <div className="h-4 bg-slate-100 rounded-full w-full"></div>
                  <div className="h-4 bg-slate-100 rounded-full w-2/3"></div>
                </div>
              ) : (
                <p className="text-slate-600 leading-relaxed font-medium text-sm md:text-base italic">"{insight}"</p>
              )}
            </div>

            <AdPlaceholder type="inline" lang={lang} />

            <HourlyForecast hourly={weather?.hourly || []} lang={lang} />
            
            <WeatherNews news={newsData.news} sources={newsData.sources} lang={lang} />

            <div className="space-y-6">
              {weather && <WeatherLayersMap lat={weather.location.lat} lon={weather.location.lon} lang={lang} />}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {weather && <SatelliteMap lat={weather.location.lat} lon={weather.location.lon} locationName={weather.location.name} lang={lang} />}
                {weather && <WindMap lat={weather.location.lat} lon={weather.location.lon} speed={weather.current.windSpeed} direction={weather.current.windDirection} lang={lang} />}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <WeeklyForecast daily={weather?.daily || []} lang={lang} />
            {weather && <SunPath sunrise={weather.astronomy.sunrise} sunset={weather.astronomy.sunset} lang={lang} />}
            
            <AdPlaceholder type="sidebar" lang={lang} />
          </div>
        </div>

        <div className="mt-12">
           <AdPlaceholder type="banner" lang={lang} />
        </div>
      </main>
      
      <footer className="max-w-7xl mx-auto px-4 mt-16 text-center border-t border-slate-200 pt-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 text-left">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600 p-1.5 rounded-lg">
                <Sun className="text-white w-4 h-4" />
              </div>
              <span className="font-black text-slate-800 text-lg">{APP_NAME}</span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              O seu companheiro meteorológico inteligente. Previsões precisas, insights de IA e radar global.
            </p>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Legal</h4>
            <ul className="space-y-2">
              <li><button onClick={() => setLegalPage('privacy')} className="text-xs text-slate-600 hover:text-blue-600 flex items-center gap-2 transition-colors"><ShieldCheck size={12}/> {t.privacyTitle}</button></li>
              <li><button onClick={() => setLegalPage('terms')} className="text-xs text-slate-600 hover:text-blue-600 flex items-center gap-2 transition-colors"><FileText size={12}/> {t.termsTitle}</button></li>
              <li><button onClick={() => setLegalPage('about')} className="text-xs text-slate-600 hover:text-blue-600 flex items-center gap-2 transition-colors"><Info size={12}/> {t.aboutTitle}</button></li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Suporte</h4>
            <ul className="space-y-2">
              <li><button onClick={() => setLegalPage('contact')} className="text-xs text-slate-600 hover:text-blue-600 flex items-center gap-2 transition-colors"><MessageSquare size={12}/> {t.contactTitle}</button></li>
              <li><a href="mailto:nilmar@agrobests.com.br" className="text-xs text-slate-600 hover:text-blue-600 flex items-center gap-2 transition-colors"><Mail size={12}/> nilmar@agrobests.com.br</a></li>
            </ul>
          </div>
        </div>

        {deferredPrompt && !isNative && (
          <button 
            onClick={handleInstall}
            className="md:hidden w-full mb-8 py-4 bg-slate-900 text-white text-xs font-black uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 active:bg-black transition-all"
          >
            <Download size={16} /> {t.installBtn}
          </button>
        )}

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-8 border-t border-slate-100">
          <p className="text-slate-400 text-[9px] font-bold uppercase tracking-[0.2em]">{APP_NAME} GLOBAL • © {new Date().getFullYear()}</p>
          <div className="flex items-center gap-4">
             <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
             <span className="text-[9px] font-black text-slate-400 uppercase">Sistemas Operacionais</span>
          </div>
        </div>
        <p className="text-slate-400 text-[10px] leading-relaxed max-w-2xl mx-auto opacity-60 mb-8">{t.footerText}</p>
      </footer>

      {legalPage && (
        <LegalModal 
          type={legalPage} 
          lang={lang} 
          onClose={() => setLegalPage(null)} 
        />
      )}
    </div>
  );
};

export default App;
