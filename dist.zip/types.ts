
export type Language = 'pt' | 'en' | 'es';

export interface WeatherAlert {
  id: string;
  type: 'storm' | 'uv' | 'flood' | 'heat' | 'humidity' | 'pollen' | 'wind' | 'cold';
  severity: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
}

export interface WeatherData {
  current: {
    temp: number;
    description: number;
    icon: number;
    humidity: number;
    windSpeed: number;
    windDirection: number;
    pressure: number;
    uvIndex: number;
    visibility: number;
    isDay: boolean;
  };
  hourly: HourlyForecast[];
  daily: DailyForecast[];
  astronomy: {
    sunrise: string;
    sunset: string;
  };
  location: {
    name: string;
    lat: number;
    lon: number;
  };
  pollen?: {
    grass: number;
    ragweed: number;
    birch: number;
  };
  alerts: WeatherAlert[];
}

export interface HourlyForecast {
  time: string;
  temp: number;
  icon: number;
  pop: number;
}

export interface DailyForecast {
  date: string;
  minTemp: number;
  maxTemp: number;
  icon: number;
  description: number;
}

export interface GeocodingResult {
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  admin1?: string;
}
