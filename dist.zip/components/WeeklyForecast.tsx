
import React from 'react';
import { DailyForecast as DailyType, Language } from '../types';
import { WEATHER_ICONS, getWeatherDescription } from '../constants';
import { translations } from '../translations';

interface WeeklyForecastProps {
  daily: DailyType[];
  lang: Language;
}

const WeeklyForecast: React.FC<WeeklyForecastProps> = ({ daily, lang }) => {
  const t = translations[lang];
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    if (date.toDateString() === today.toDateString()) return t.today;
    return new Intl.DateTimeFormat(lang === 'en' ? 'en-US' : lang === 'es' ? 'es-ES' : 'pt-BR', { weekday: 'short' }).format(date);
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">{t.weeklyTitle}</h3>
      <div className="space-y-4">
        {daily.map((day, idx) => (
          <div key={idx} className="flex items-center justify-between group cursor-default">
            <div className="w-12">
              <span className="text-sm font-bold text-gray-700 capitalize">
                {formatDate(day.date)}
              </span>
            </div>
            <div className="flex items-center gap-3 flex-1 px-4">
              <div className="scale-[1.2]">{WEATHER_ICONS[day.icon]}</div>
              <span className="text-xs text-gray-500 font-medium truncate hidden sm:block">
                {getWeatherDescription(day.description, lang)}
              </span>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1 w-24 justify-end">
                <span className="text-sm font-bold text-gray-800">{day.maxTemp}°</span>
                <span className="text-sm text-gray-400 font-medium">{day.minTemp}°</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WeeklyForecast;
