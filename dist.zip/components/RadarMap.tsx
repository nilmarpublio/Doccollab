
import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

interface RadarMapProps {
  lat: number;
  lon: number;
}

const RadarMap: React.FC<RadarMapProps> = ({ lat, lon }) => {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize map
    mapRef.current = L.map(containerRef.current).setView([lat, lon], 8);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap'
    }).addTo(mapRef.current);

    // Weather radar layer from RainViewer (free)
    // Using a sample timestamp for demo purposes, usually you'd fetch latest from their API
    const radarLayer = L.tileLayer('https://tilecache.rainviewer.com/v2/radar/1672531200/256/{z}/{x}/{y}/2/1_1.png', {
      opacity: 0.6,
      attribution: '&copy; RainViewer'
    }).addTo(mapRef.current);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [lat, lon]);

  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Radar Meteorológico</h3>
        <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full font-medium">Ao Vivo</span>
      </div>
      <div id="radar-map" ref={containerRef} className="z-0"></div>
    </div>
  );
};

export default RadarMap;
