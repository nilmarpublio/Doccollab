
import React from 'react';
import { HourlyForecast as HourlyType, Language } from '../types';
import { WEATHER_ICONS } from '../constants';
import { translations } from '../translations';

interface HourlyForecastProps {
  hourly: HourlyType[];
  lang: Language;
}

const HourlyForecast: React.FC<HourlyForecastProps> = ({ hourly, lang }) => {
  const t = translations[lang];
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{t.hourlyTitle}</h3>
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest animate-pulse">{t.hourlyScroll}</span>
      </div>
      
      <div className="flex gap-3 overflow-x-auto pb-2 hide-scrollbar snap-x snap-mandatory touch-pan-x">
        {hourly.map((item, idx) => {
          const isNow = idx === 0;
          return (
            <div 
              key={idx} 
              className={`flex-shrink-0 w-20 flex flex-col items-center p-3 rounded-2xl transition-all snap-center
                ${isNow ? 'bg-blue-50 ring-1 ring-blue-100' : 'hover:bg-slate-50'}`}
            >
              <span className={`text-[11px] font-bold mb-3 ${isNow ? 'text-blue-600' : 'text-gray-400'}`}>
                {isNow ? t.now : `${new Date(item.time).getHours()}:00`}
              </span>
              
              <div className="text-2xl mb-3 transform transition-transform group-hover:scale-110">
                {WEATHER_ICONS[item.icon]}
              </div>
              
              <span className={`text-sm font-black ${isNow ? 'text-blue-700' : 'text-gray-800'}`}>
                {item.temp}°
              </span>
              
              {item.pop > 0 ? (
                <div className="flex items-center gap-0.5 mt-1 text-blue-500">
                  <span className="text-[9px] font-black uppercase">{item.pop}%</span>
                </div>
              ) : (
                <div className="h-4"></div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HourlyForecast;
