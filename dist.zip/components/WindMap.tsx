
import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Wind } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface WindMapProps {
  lat: number;
  lon: number;
  speed: number;
  direction: number;
  lang: Language;
}

const WindMap: React.FC<WindMapProps> = ({ lat, lon, speed, direction, lang }) => {
  const t = translations[lang];
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const requestRef = useRef<number>(0);

  useEffect(() => {
    if (!containerRef.current) return;
    mapRef.current = L.map(containerRef.current, { zoomControl: true, scrollWheelZoom: false, attributionControl: false }).setView([lat, lon], 10);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapRef.current);
    const canvas = document.createElement('canvas');
    canvas.style.position = 'absolute'; canvas.style.top = '0'; canvas.style.left = '0'; canvas.style.pointerEvents = 'none'; canvas.style.zIndex = '1000';
    containerRef.current.appendChild(canvas);
    canvasRef.current = canvas;
    const resize = () => { if (containerRef.current) { canvas.width = containerRef.current.clientWidth; canvas.height = containerRef.current.clientHeight; } };
    resize();
    const particles: any[] = [];
    for (let i = 0; i < 100; i++) particles.push({ x: Math.random() * canvas.width, y: Math.random() * canvas.height, len: Math.random() * 20 + 10, opacity: Math.random() });
    const animate = () => {
      const ctx = canvas.getContext('2d'); if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const angleRad = (direction - 90) * (Math.PI / 180);
      particles.forEach(p => {
        ctx.beginPath(); ctx.strokeStyle = `rgba(34, 211, 238, ${p.opacity * 0.5})`;
        ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + Math.cos(angleRad) * p.len, p.y + Math.sin(angleRad) * p.len); ctx.stroke();
        p.x += Math.cos(angleRad) * 2; p.y += Math.sin(angleRad) * 2;
        if (p.x < 0) p.x = canvas.width; if (p.x > canvas.width) p.x = 0; if (p.y < 0) p.y = canvas.height; if (p.y > canvas.height) p.y = 0;
      });
      requestRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => { cancelAnimationFrame(requestRef.current); if (mapRef.current) mapRef.current.remove(); };
  }, [lat, lon, direction]);

  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mt-6 overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <div><h3 className="text-lg font-semibold text-gray-800">{t.windMapTitle}</h3><p className="text-xs text-gray-500">{t.windMapSub}</p></div>
        <div className="text-right"><p className="text-sm font-bold">{speed} km/h</p></div>
      </div>
      <div ref={containerRef} className="h-[300px] w-full rounded-xl relative bg-slate-900 overflow-hidden"></div>
    </div>
  );
};

export default WindMap;
