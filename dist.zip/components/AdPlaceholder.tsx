
import React, { useEffect, useRef } from 'react';
import { Language } from '../types';
import { translations } from '../translations';
import { Tag } from 'lucide-react';

interface AdPlaceholderProps {
  type: 'banner' | 'sidebar' | 'inline';
  lang: Language;
  adSlot?: string; 
}

const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ type, lang, adSlot }) => {
  const t = translations[lang];
  const adInitialized = useRef(false);

  useEffect(() => {
    // Apenas tenta inicializar se tiver um adSlot e se ainda não foi inicializado para este componente
    if (adSlot && !adInitialized.current) {
      try {
        const adsbygoogle = (window as any).adsbygoogle;
        if (adsbygoogle) {
          adsbygoogle.push({});
          adInitialized.current = true;
        } else {
          // Se o script do AdSense ainda não carregou, tenta novamente em breve
          const timeout = setTimeout(() => {
            if ((window as any).adsbygoogle && !adInitialized.current) {
              (window as any).adsbygoogle.push({});
              adInitialized.current = true;
            }
          }, 2000);
          return () => clearTimeout(timeout);
        }
      } catch (e) {
        console.error("AdSense logic error:", e);
      }
    }
  }, [adSlot]);

  const styles = {
    banner: 'w-full min-h-[90px] mb-6',
    sidebar: 'w-full min-h-[250px] sticky top-4',
    inline: 'w-full min-h-[250px] my-6',
  };

  // Se não houver adSlot, mostra o placeholder de desenvolvimento
  if (!adSlot) {
    return (
      <div className={`${styles[type]} bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2rem] flex items-center justify-center overflow-hidden relative transition-all`}>
        <div className="absolute top-3 left-4 flex items-center gap-1.5 px-2 py-0.5 bg-white/80 rounded-full border border-slate-100 z-10">
          <Tag size={10} className="text-slate-400" />
          <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">{t.adLabel} (Demo)</span>
        </div>
        <div className="text-center p-6">
          <h4 className="text-slate-400 font-bold text-xs">{t.adPlaceholder}</h4>
          <p className="text-slate-300 text-[10px] uppercase mt-1">Aguardando ID do Bloco</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      key={adSlot} // Força recriação se o slot mudar
      className={`${styles[type]} overflow-hidden flex justify-center items-center bg-white rounded-[2rem] border border-slate-100 shadow-sm`}
    >
      <ins className="adsbygoogle"
           style={{ display: 'block' }}
           data-ad-client="ca-pub-4696829859136190"
           data-ad-slot={adSlot}
           data-ad-format="auto"
           data-full-width-responsive="true"></ins>
    </div>
  );
};

export default AdPlaceholder;
