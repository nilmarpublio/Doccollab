
import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { Language } from '../types';
import { translations } from '../translations';

interface SatelliteMapProps {
  lat: number;
  lon: number;
  locationName: string;
  lang: Language;
}

const SatelliteMap: React.FC<SatelliteMapProps> = ({ lat, lon, locationName, lang }) => {
  const t = translations[lang];
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    mapRef.current = L.map(containerRef.current, { zoomControl: true, scrollWheelZoom: false }).setView([lat, lon], 13);
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19 }).addTo(mapRef.current);
    const icon = L.divIcon({ className: 'custom-div-icon', html: `<div style="background-color: #3b82f6; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`, iconSize: [12, 12], iconAnchor: [6, 6] });
    L.marker([lat, lon], { icon }).addTo(mapRef.current).bindPopup(`<b>${locationName}</b>`).openPopup();
    return () => { if (mapRef.current) mapRef.current.remove(); };
  }, [lat, lon, locationName]);

  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mt-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{t.satelliteTitle}</h3>
          <p className="text-xs text-gray-500">{t.satelliteSub}</p>
        </div>
        <span className="text-[10px] px-2 py-1 bg-blue-100 text-blue-700 rounded-md font-bold">HD</span>
      </div>
      <div ref={containerRef} className="h-[400px] w-full rounded-xl z-0" style={{ background: '#e5e7eb' }}></div>
    </div>
  );
};

export default SatelliteMap;
