
import React from 'react';
import { Newspaper, ExternalLink } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface NewsItem {
  title: string;
  summary: string;
  url: string;
}

interface WeatherNewsProps {
  news: NewsItem[];
  sources: any[];
  lang: Language;
}

const WeatherNews: React.FC<WeatherNewsProps> = ({ news, sources, lang }) => {
  const t = translations[lang];
  if (!news || news.length === 0) return null;

  return (
    <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-slate-900 rounded-2xl flex items-center justify-center">
          <Newspaper className="text-white w-5 h-5" />
        </div>
        <h3 className="font-extrabold text-slate-800 tracking-tight">{t.newsTitle}</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {news.map((item, idx) => (
          <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
            <div>
              <h4 className="font-bold text-slate-800 text-sm mb-2">{item.title}</h4>
              <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mb-4">{item.summary}</p>
            </div>
            <a 
              href={item.url || (sources[idx]?.uri)} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-blue-600 hover:text-blue-700"
            >
              {t.newsMore} <ExternalLink size={12} />
            </a>
          </div>
        ))}
      </div>
      
      {sources.length > 0 && (
        <div className="mt-6 pt-4 border-t border-slate-50">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{t.newsSource}:</p>
          <div className="flex flex-wrap gap-2">
            {sources.map((s, i) => (
              <a key={i} href={s.uri} target="_blank" className="text-[10px] bg-slate-100 px-2 py-1 rounded-md text-slate-500 truncate max-w-[150px]">{s.title || 'Web'}</a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherNews;
