
import React from 'react';
import { X, ShieldCheck, FileText, Info, Mail } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface LegalModalProps {
  type: 'privacy' | 'terms' | 'about' | 'contact';
  lang: Language;
  onClose: () => void;
}

const LegalModal: React.FC<LegalModalProps> = ({ type, lang, onClose }) => {
  const t = translations[lang];

  const getContent = () => {
    switch (type) {
      case 'privacy':
        return {
          title: t.privacyTitle,
          icon: <ShieldCheck size={24} className="text-blue-600" />,
          text: t.privacyText
        };
      case 'terms':
        return {
          title: t.termsTitle,
          icon: <FileText size={24} className="text-blue-600" />,
          text: t.termsText
        };
      case 'about':
        return {
          title: t.aboutTitle,
          icon: <Info size={24} className="text-blue-600" />,
          text: t.aboutText
        };
      case 'contact':
        return {
          title: t.contactTitle,
          icon: <Mail size={24} className="text-blue-600" />,
          text: (
            <div className="space-y-4">
              <p>{t.contactText}</p>
              <a 
                href="mailto:nilmar@agrobests.com.br" 
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
              >
                nilmar@agrobests.com.br
              </a>
            </div>
          )
        };
    }
  };

  const content = getContent();

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300"
        onClick={onClose}
      />
      <div className="relative bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 slide-in-from-bottom-4 duration-300">
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-50 rounded-2xl">
                {content.icon}
              </div>
              <h2 className="text-xl font-extrabold text-slate-800 tracking-tight">{content.title}</h2>
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition-colors"
            >
              <X size={24} />
            </button>
          </div>
          
          <div className="text-slate-600 leading-relaxed text-sm md:text-base font-medium">
            {content.text}
          </div>

          <div className="mt-10">
            <button 
              onClick={onClose}
              className="w-full py-4 bg-slate-100 text-slate-600 font-black uppercase tracking-widest text-xs rounded-2xl hover:bg-slate-200 transition-colors"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalModal;
