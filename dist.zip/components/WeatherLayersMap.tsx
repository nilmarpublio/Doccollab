
import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface WeatherLayersMapProps {
  lat: number;
  lon: number;
  lang: Language;
}

type LayerType = 'radar' | 'satellite';

const WeatherLayersMap: React.FC<WeatherLayersMapProps> = ({ lat, lon, lang }) => {
  const t = translations[lang];
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const layerRef = useRef<L.TileLayer | null>(null);
  const intervalRef = useRef<number | null>(null);

  const [activeLayer, setActiveLayer] = useState<LayerType>('radar');
  const [timestamps, setTimestamps] = useState<number[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  useEffect(() => {
    if (!containerRef.current) return;
    mapRef.current = L.map(containerRef.current, { zoomControl: true, scrollWheelZoom: false }).setView([lat, lon], 6);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png').addTo(mapRef.current);
    fetchTimestamps();
    return () => { if (mapRef.current) mapRef.current.remove(); };
  }, [lat, lon]);

  const fetchTimestamps = async () => {
    try {
      const response = await fetch('https://api.rainviewer.com/public/weather-maps.json');
      const data = await response.json();
      const frames = activeLayer === 'radar' ? data.radar.past.map((f: any) => f.time) : data.satellite.infrared.map((f: any) => f.time);
      setTimestamps(frames);
      setCurrentIndex(frames.length - 1);
    } catch (e) {}
  };

  useEffect(() => { fetchTimestamps(); }, [activeLayer]);

  useEffect(() => {
    if (isPlaying && timestamps.length > 0) {
      intervalRef.current = window.setInterval(() => setCurrentIndex((prev) => (prev + 1) % timestamps.length), 1000);
    } else if (intervalRef.current) clearInterval(intervalRef.current);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isPlaying, timestamps]);

  useEffect(() => {
    if (!mapRef.current || timestamps.length === 0) return;
    const timestamp = timestamps[currentIndex];
    const layerPath = activeLayer === 'radar' ? 'radar' : 'satellite';
    const colorScheme = activeLayer === 'radar' ? '2' : '0';
    if (layerRef.current) mapRef.current.removeLayer(layerRef.current);
    layerRef.current = L.tileLayer(`https://tilecache.rainviewer.com/v2/${layerPath}/${timestamp}/256/{z}/{x}/{y}/${colorScheme}/1_1.png`, { opacity: 0.8 }).addTo(mapRef.current);
  }, [currentIndex, timestamps, activeLayer]);

  return (
    <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mt-6 overflow-hidden">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-3">
        <div>
          <h3 className="text-lg font-semibold text-gray-800">{t.monitoringTitle}</h3>
          <p className="text-xs text-gray-500">{t.monitoringSub}</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button onClick={() => setActiveLayer('radar')} className={`px-4 py-1.5 text-xs font-bold rounded-lg ${activeLayer === 'radar' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>{t.precipitation}</button>
          <button onClick={() => setActiveLayer('satellite')} className={`px-4 py-1.5 text-xs font-bold rounded-lg ${activeLayer === 'satellite' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>{t.clouds}</button>
        </div>
      </div>
      <div className="relative">
        <div ref={containerRef} className="h-[400px] w-full rounded-xl z-0"></div>
        {activeLayer === 'radar' && (
          <div className="absolute bottom-6 left-4 bg-white/90 backdrop-blur p-2 rounded-lg shadow-sm z-[1000] flex flex-col gap-1">
            <span className="text-[10px] font-bold text-gray-400 uppercase">{t.intensity}</span>
            <div className="flex h-2 w-32 rounded-full overflow-hidden">
              <div className="bg-blue-300 w-1/4"></div><div className="bg-green-400 w-1/4"></div><div className="bg-yellow-400 w-1/4"></div><div className="bg-red-500 w-1/4"></div>
            </div>
            <div className="flex justify-between text-[8px] font-bold text-gray-500 uppercase"><span>{t.light}</span><span>{t.heavy}</span></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WeatherLayersMap;
