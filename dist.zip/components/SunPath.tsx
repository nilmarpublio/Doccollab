
import React, { useMemo } from 'react';
import { Sunrise, Sunset } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface SunPathProps {
  sunrise: string;
  sunset: string;
  lang: Language;
}

const SunPath: React.FC<SunPathProps> = ({ sunrise, sunset, lang }) => {
  const t = translations[lang];
  const { progress, sunriseLabel, sunsetLabel } = useMemo(() => {
    const parseTime = (iso: string) => new Date(iso).getTime();
    const now = new Date().getTime();
    const start = parseTime(sunrise);
    const end = parseTime(sunset);
    let p = (now - start) / (end - start);
    p = Math.max(0, Math.min(1, p));
    return {
      progress: p,
      sunriseLabel: new Date(sunrise).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sunsetLabel: new Date(sunset).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
  }, [sunrise, sunset]);

  const width = 300;
  const height = 100;
  const sunX = 20 + (width - 40) * progress;
  const sunY = height - Math.sin(progress * Math.PI) * (height - 20) - 10;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
      <h3 className="text-lg font-semibold text-gray-800 mb-6">{t.sunPathTitle}</h3>
      <div className="relative w-full max-w-[400px] mx-auto">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
          <path d={`M 20,${height-10} Q ${width/2},${-(height-60)} ${width-20},${height-10}`} fill="none" stroke="#e2e8f0" strokeWidth="2" strokeDasharray="4 4"/>
          <circle cx={sunX} cy={sunY} r="6" fill="#fbbf24" className="animate-pulse shadow-lg" />
          <line x1="0" y1={height-10} x2={width} y2={height-10} stroke="#cbd5e1" strokeWidth="1" />
        </svg>
        <div className="flex justify-between mt-4">
          <div className="flex flex-col items-start">
            <div className="flex items-center text-orange-500 mb-1">
              <Sunrise size={18} className="mr-1" />
              <span className="font-bold text-sm">{t.sunrise}</span>
            </div>
            <span className="text-gray-500 text-xs">{sunriseLabel}</span>
          </div>
          <div className="flex flex-col items-end">
            <div className="flex items-center text-blue-500 mb-1">
              <span className="font-bold text-sm mr-1">{t.sunset}</span>
              <Sunset size={18} />
            </div>
            <span className="text-gray-500 text-xs">{sunsetLabel}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SunPath;
