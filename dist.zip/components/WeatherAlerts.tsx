
import React from 'react';
import { AlertTriangle, Info, Zap, ThermometerSnowflake, Wind, Droplets, Sun, Flower2 } from 'lucide-react';
import { WeatherAlert } from '../types';

interface WeatherAlertsProps {
  alerts: WeatherAlert[];
}

const WeatherAlerts: React.FC<WeatherAlertsProps> = ({ alerts }) => {
  if (alerts.length === 0) return null;

  const getIcon = (type: WeatherAlert['type']) => {
    switch (type) {
      case 'storm': return <Zap className="w-5 h-5" />;
      case 'uv': return <Sun className="w-5 h-5" />;
      case 'flood': return <Droplets className="w-5 h-5" />;
      case 'heat': return <AlertTriangle className="w-5 h-5" />;
      case 'cold': return <ThermometerSnowflake className="w-5 h-5" />;
      case 'humidity': return <Droplets className="w-5 h-5 opacity-50" />;
      case 'wind': return <Wind className="w-5 h-5" />;
      case 'pollen': return <Flower2 className="w-5 h-5" />;
      default: return <Info className="w-5 h-5" />;
    }
  };

  const getColors = (severity: WeatherAlert['severity']) => {
    switch (severity) {
      case 'critical': return 'bg-red-50 border-red-200 text-red-800 ring-red-500';
      case 'warning': return 'bg-orange-50 border-orange-200 text-orange-800 ring-orange-500';
      case 'info': return 'bg-blue-50 border-blue-200 text-blue-800 ring-blue-500';
    }
  };

  return (
    <div className="space-y-3 mb-6">
      {alerts.map((alert) => (
        <div 
          key={alert.id} 
          className={`relative overflow-hidden border p-4 rounded-2xl flex gap-4 animate-in fade-in slide-in-from-top-4 duration-500 ${getColors(alert.severity)}`}
        >
          {alert.severity === 'critical' && (
            <span className="absolute top-0 right-0 p-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
              </span>
            </span>
          )}
          
          <div className={`mt-0.5 p-2 rounded-xl bg-white/50 backdrop-blur-sm`}>
            {getIcon(alert.type)}
          </div>
          
          <div className="flex-1">
            <h4 className="font-bold text-sm uppercase tracking-tight">{alert.title}</h4>
            <p className="text-xs opacity-90 mt-1 font-medium leading-relaxed">{alert.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default WeatherAlerts;
