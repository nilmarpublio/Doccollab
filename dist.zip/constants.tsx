
import React from 'react';
import { 
  Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, 
  CloudSnow, CloudSun, Sun, Moon
} from 'lucide-react';
import { Language } from './types';

export const WEATHER_ICONS: Record<number, React.ReactNode> = {
  0: <Sun className="text-yellow-400" />,
  1: <CloudSun className="text-yellow-200" />,
  2: <CloudSun className="text-gray-300" />,
  3: <Cloud className="text-gray-400" />,
  45: <CloudFog className="text-gray-300" />,
  48: <CloudFog className="text-gray-300" />,
  51: <CloudDrizzle className="text-blue-300" />,
  53: <CloudDrizzle className="text-blue-400" />,
  55: <CloudDrizzle className="text-blue-500" />,
  61: <CloudRain className="text-blue-400" />,
  63: <CloudRain className="text-blue-500" />,
  65: <CloudRain className="text-blue-600" />,
  71: <CloudSnow className="text-white" />,
  73: <CloudSnow className="text-white" />,
  75: <CloudSnow className="text-white" />,
  80: <CloudRain className="text-blue-400" />,
  81: <CloudRain className="text-blue-500" />,
  82: <CloudRain className="text-blue-600" />,
  95: <CloudLightning className="text-purple-500" />,
};

export const getWeatherDescription = (code: number, lang: Language): string => {
  const descriptions: Record<number, Record<Language, string>> = {
    0: { pt: 'Céu Limpo', en: 'Clear Sky', es: 'Cielo Despejado' },
    1: { pt: 'Predominantemente Limpo', en: 'Mainly Clear', es: 'Mayormente Despejado' },
    2: { pt: 'Parcialmente Nublado', en: 'Partly Cloudy', es: 'Parcialmente Nublado' },
    3: { pt: 'Nublado', en: 'Overcast', es: 'Nublado' },
    45: { pt: 'Nevoeiro', en: 'Fog', es: 'Niebla' },
    48: { pt: 'Nevoeiro Escarchado', en: 'Rime Fog', es: 'Niebla Escarchada' },
    51: { pt: 'Chuvisco Leve', en: 'Light Drizzle', es: 'Llovizna Ligera' },
    53: { pt: 'Chuvisco Moderado', en: 'Moderate Drizzle', es: 'Llovizna Moderada' },
    55: { pt: 'Chuvisco Denso', en: 'Dense Drizzle', es: 'Llovizna Densa' },
    61: { pt: 'Chuva Leve', en: 'Slight Rain', es: 'Lluvia Ligera' },
    63: { pt: 'Chuva Moderada', en: 'Moderate Rain', es: 'Lluvia Moderada' },
    65: { pt: 'Chuva Forte', en: 'Heavy Rain', es: 'Lluvia Fuerte' },
    71: { pt: 'Neve Leve', en: 'Slight Snow', es: 'Nieve Ligera' },
    73: { pt: 'Neve Moderada', en: 'Moderate Snow', es: 'Nieve Moderada' },
    75: { pt: 'Neve Forte', en: 'Heavy Snow', es: 'Nieve Fuerte' },
    80: { pt: 'Pancadas Leves', en: 'Slight Rain Showers', es: 'Chubascos Ligeros' },
    81: { pt: 'Pancadas Moderadas', en: 'Moderate Rain Showers', es: 'Chubascos Moderados' },
    82: { pt: 'Pancadas Fortes', en: 'Heavy Rain Showers', es: 'Chubascos Fuertes' },
    95: { pt: 'Tempestade', en: 'Thunderstorm', es: 'Tormenta' },
  };
  return descriptions[code]?.[lang] || (lang === 'en' ? 'Unknown' : lang === 'es' ? 'Desconocido' : 'Desconhecido');
};
